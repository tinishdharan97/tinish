<?php
require('connection.php');
if(isset($_POST['update'])){
    $id=$_GET['id'];
    $email=$_POST['email'];
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $age=$_POST['age'];
    $gender=$_POST['gender'];
    $option=$_POST['option'];
    $class=$_POST['class'];
    $telephone=$_POST['telephone'];


       $update="UPDATE `insert` SET `email`='$email',`first_name`='$firstname',`last_name`='$lastname',`age`='$age',
       `gender`='$gender',`option`='$option',`class`='$class',`telephone`='$telephone' WHERE `id`='$id'";

       $query=mysqli_query($con,$update);

        if ($update) {
        ?>
        <div class="alert alert-success">
          <strong class="icon-alert"><i class="fa fa-exclamation-triangle"></i></strong>Updated Successfull 
        </div>
        <?php
        }
        else {
        ?>
        <div class="alert alert-danger">
          <strong class="icon-alert"><i class="fa fa-exclamation-triangle"></i></strong>
          There Was Problem in update  Please Try Again 
        </div>
        <?php
        }
        }
        ?>