<?php
include 'connection.php';
$query= "SELECT * FROM user ";
$data=$conn->query($query);
echo '<table width="70%" border="1" cellpadding="5">
<tr>
<th>customer_id</th>
<th>Customer_name</th>
<th>Customer_email</th>
<th>Customer_password</th> 
<th>date_of_sent</th></tr>';
foreach($data as $row)
{
    echo'
    <tr>
    <td>'.$row["id"].'</td>
    <td>'.$row["name"].'</td>
    <td>'.$row["email"].'</td>
    <td>'.$row["message"].'</td>
    <td>'.$row["date"].'</td></tr>
    ';
}
echo '</table>';
?>