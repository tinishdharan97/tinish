<?php
require('connection.php');
if (isset($_POST['delete'])) {
$id=$_GET['id'];
$del="DELETE FROM `message` WHERE `id`='$id'";
$delete=mysqli_query($con,$del);
if ($delete) {
?>
<div class="alert alert-success">
  <strong class="icon-alert"><i class="fa fa-exclamation-triangle"></i></strong>Deleted Successfull 
</div>
<?php
}
else {
?>
<div class="alert alert-danger">
  <strong class="icon-alert"><i class="fa fa-exclamation-triangle"></i></strong>There Was Problem in Delete Please Try Again 
</div>
<?php
}
}
?>