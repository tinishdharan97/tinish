<?php
$server="localhost";
$user="root";
$pass="";
$db="school";
$con=mysqli_connect($server,$user,$pass,$db) or die("could not connect");
?>