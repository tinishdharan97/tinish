 <?php
require('insert.php');
require('message.php');
?> 

<html >
<head>
<title>School Name</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="bootstrap.css">
<style>
form{
  width:500px;
  margin:auto;
}
.modal-content{
  padding:50px;
}
</style>
</head>
<body id="top">
<div class="wrapper col1">
  <div id="head">
    <h1><a href="index.php">School Name</a></h1>
    <p>School Moto</p>
    <div id="topnav">
      <ul>
        <li><a class="active" href="index.php">Home</a></li>
        <li id="regist"><a href="#">Registration</a></li>
        <li ><a href="commenthome.php">Comment</a></li>
         <li><a href="login.php">Admin</a></li>
      </ul>
    </div>
  <div class="modal text-center">
  <div class="modal-content text-center " style="width:fit-content;margin:auto;">
  <div class="btn btn-danger" id="closeModal">Close</div><br><br>
  <form action="index.php" method="post">
  <div class="form-group">
  <input type="text" name="email" placeholder="Email" id="name" class="form-control">
  </div>
  <div class="form-group">
  <input type="text" name="first_name" placeholder="First name "  id="name" class="form-control">
  </div>
  <div class="form-group">
  <input type="text" name="last_name" placeholder="Last name"  id=" " class="form-control">
  </div>
  <div class="form-group">
  <input type="number" name="age" placeholder="Age"  id="  " class="form-control">
  </div>
  <div class="form-group">
    <select class="form-control" name="gender">
      <option>
        Gender
      </option>
      <option>
        Male
      </option>
      <option>
        Female
      </option>
    </select>
  </div>
  <div class="form-group">
  <input type="text" name="option" placeholder="Option"  id=" " class="form-control">
  </div>
    <div class="form-group">
  <input type="text" name="class" placeholder="Class"  id=" " class="form-control">
  </div>

    <div class="form-group">
  <input type="number" name="telephone" placeholder="Telephone"  id="  " class="form-control">
  </div>

  <div class="form-group">
<input type="submit" class="btn btn-primary" value="Regist" name="regist" id="register" >
</div>
  </form>
  </div>
  </div>
  </div>
</div>
<div class="wrapper col2">
  <div id="gallery" style="width:100%;">
    <ul>
      <li class="placeholder" style="background-image:url(images/demo/10.jpg);">Image Holder</li>
      
    </ul>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
    <div id="content">
      <h1>About This School Management system</h1>
      <p>This is a free project from irezon.com</p>
      <p>Nelson Mandela quotes about education: ... Education is the most powerful weapon which you can use to change the world. The power of education extends beyond the development of skills we need for economic success. It can contribute to nation-building and reconciliation.</p>
      <p>Nelson Mandela quotes about education: ... Education is the most powerful weapon which you can use to change the world. The power of education extends beyond the development of skills we need for economic success. It can contribute to nation-building and reconciliation.</a>.</p>
      <p>Nelson Mandela quotes about education: ... Education is the most powerful weapon which you can use to change the world. “The power of education extends beyond the development of skills we need for economic success. It can contribute to nation-building and reconciliation.</p>
      <p>Semalique tor sempus vestibulum libero nibh pretium eget eu elit montes. Sedsemporttis sit intesque felit quis elis et cursuspenatibulum tincidunt non curabitae.</p>
      <div class="homecontent">
        <ul>
          <li>
            <p class="imgholder"><img src="images/demo/286x100.gif" alt="" /></p>
            <h2>School image 1</h2>
            
            <p>education is to teach one to think intensively and to think critically. Intelligence plus character - that is the goal of true education.</p>
            <p class="readmore"><a href="#">Read More &raquo;</a></p>
          </li>
          <li class="last">
            <p class="imgholder"><img src="images/demo/286x100.gif" alt="" /></p>
            <h2>School image 2</h2>
            <p>education is to teach one to think intensively and to think critically. Intelligence plus character - that is the goal of true education</p>
            <p class="readmore"><a href="#">Read More &raquo;</a></p>
          </li>
        </ul>
        <div class="clear"></div>
      </div>
      
    </div>
    <div id="column">
      <div id="featured">
        <ul>
          <li>
            <h2>School name </h2>
            <p class="imgholder"><img src="images/demo/240x90.gif" alt="" /></p>
            <p>Education is the passport to the future, for tomorrow belongs to those who prepare for it today.</p>
            <p class="more"><a href="#">Read More &raquo;</a></p>
          </li>
        </ul>
      </div>
      <div class="holder">
        <div class="imgholder"><img src="images/demo/290x100.gif" alt="" /></div>
        <p>education is to teach one to think intensively and to think critically. Intelligence plus character - that is the goal of true education</p>
        <p class="readmore"><a href="https://www.irezon.com/">Read More &raquo;</a></p>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col5">
  <div id="footer">
    <div id="contactform">
      <h2>Why Not Contact Us Today !</h2>
      <form action="index.php" method="post">
        <fieldset >
          <legend><font color="white">Contact Form</font></legend>
          <label for="fullname">Name:
            <input id="fullname" name="fullname"  type="text">
          </label>
          <label for="emailaddress" class="margin">Email:
            <input  id="emailaddress" name="emailadress" type="email" >
          </label>
          <label for="message">Comment:<br />
            <textarea id="message" name="messag" cols="40" rows="4"  >

            </textarea>
          </label>
          <p>
            <input id="submitform" name="submitform" type="submit" value="Submit">
            &nbsp;
            <input id="resetform" name="resetform" type="reset" value="Reset">
          </p>
        </fieldset>
      </form>
    </div>
  



    <div id="compdetails">
      <div id="officialdetails">
        <h2>School Information !</h2>
        <ul>
          <li>School Name Ltd</li>
          <li>Registered in England &amp; Wales</li>
          <li>School No. xxxxxxx</li>
          <li class="last">VAT No. xxxxxxxxx</li>
        </ul>
        <h2>Stay in The Know !</h2>
        <p><a href="https://www.irezon.com/">get new product </a> | <a href="https://www.irezon.com/">irezon</a></p>
      </div>
      <div id="contactdetails">
        <h2>Our Contact Details !</h2>
        <ul>
          <li>School Name</li>
          <li>Street Name &amp; Number</li>
          <li>Town</li>
          <li>Postcode/Zip</li>
          <li>Tel: xxxxx xxxxxxxxxx</li>
          <li>Fax: xxxxx xxxxxxxxxx</li>
          <li>Email: info@domain.com</li>
          <li class="last">LinkedIn: <a href="#">School Profile</a></li>
        </ul>
      </div>
      <div class="clear"></div>
    </div>

    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2019 - All Rights Reserved - <a href="#">Irezon</a></p>
      <p class="fl_right">free from<a target="_blank" href="http://www.Irezon.com/" title="Free Website Templates">irezon</a></p>
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
<script src="jquery-2.2.4.js"></script>
<script>
$('#document').ready(function () {
  $('#regist').click(function () {
    $('.modal').show(500);
  })
  $('#closeModal').click(function () {
    $('.modal').hide(500);
  })
  
})
</script>
</body>
</html>