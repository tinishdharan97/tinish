<?php
include ('connection.php');
if (isset($_POST['submitform'])) {
	$name = $_POST['fullname'];
	$email = $_POST['emailadress'];
	$messag = $_POST['messag'];

	$sql = "INSERT INTO `message`(`fullname`, `emailadress`, `messag`) VALUES ('$name','$email','$messag')";
	$link = mysqli_query($con,$sql);
	if ($link) {
		?>
		<script>
		alert("Thank you for your message ");
		</script>
		<?php
	}	
		?>
		<!-- <script>
		alert("We didn't get your message please re-type it ");
		</script> -->
		<?php

}
?>