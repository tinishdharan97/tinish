<?php
require('connection.php');
require('delete.php');
require('update.php');
?>
<html >
<head>
<title>School Name</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="bootstrap.css">
<style>

</style>
</head>
<body id="top">
<div class="wrapper col1">
  <div id="head">
    <h1><a href="index.html">School Name</a></h1>
    <p>School Moto</p>
    <div id="topnav">
      <ul>
        <li><a  href="index.php">Home</a></li>
        <li><a class="active" href="">Manage</a></li>
        <li><a  href="comment.php">Comment</a></li>
        <li><a href="index.php">Log out</a></li>
        
       
      </ul>
    </div>
  
  </div>
</div>
<div class="text-center">
  
<h1 class="text-primary"  >Welcome Admin</h1>
</div>
<div>
 
 <div class="table-responsive">
 <?php
include 'connection.php';
$query= "SELECT * FROM `insert`";
$data = mysqli_query($con,$query);
?>
<table class="table table-bordered">
<tr>
<th width="20%">Email</th>
<th width="10%">Fisrt Name</th>
<th width="10%">Last Name</th>
<th width="10%">Age</th>
<th width="10%">Gender</th>
<th width="10%">Option</th>
<th width="10%">Class</th> 
<th width="10%">Telephone</th>
<th width="10%">Action</th>
<th width="10%">Action</th>
</tr>
<?php
if (mysqli_num_rows($data)) {
  while ($row=mysqli_fetch_assoc($data)) {
  ?>
    <form action="admin.php?id=<?php echo $row['id']; ?> " method="POST" >
    <tr>
    <td> <input type="email" class="form-control" name="email" value="<?php echo $row["email"]; ?>"> </td>
    <td> <input type="text" class="form-control" name="firstname" value="<?php echo $row["first_name"]; ?>"> </td>
    <td> <input type="text" class="form-control" name="lastname" value="<?php echo $row["last_name"]; ?>"> </td>
    <td> <input type="age" class="form-control" name="age" value="<?php echo $row["age"]; ?>"> </td>
    <td> <input type="gender" class="form-control" name="gender" value="<?php echo $row["gender"]; ?>"> </td>
    <td> <input type="option" class="form-control" name="option" value="<?php echo $row["option"]; ?>"> </td>
    <td> <input type="class" class="form-control" name="class" value="<?php echo $row["class"]; ?>"> </td>
    <td> <input type="telephone" class="form-control" name="telephone" value="<?php echo $row["telephone"]; ?>"> </td>
    <td> <button class="btn btn-danger" name="delete"> Delete </button> </td>
    <td> <button class="btn btn-danger" name="update"> Update </button> </td>
    </tr>
    </form>
    <?php
}
}
echo '</table>';
?>

 </div>
 
    <div class="clear"></div>
  </div>
</div>

      
    </div>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col5">
  <div id="footer">
    <div id="contactform">
      <h2>ADMIN</h2>
      <form action="#" method="post">
        
      </form>
    </div>
    <div id="compdetails">
      <div id="officialdetails">
        <h2>ADMIN</h2>
       
       
      </div>
      <div id="contactdetails">
      
      </div>
      <div class="clear"></div>
    </div>
  
    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2019 - All Rights Reserved - <a href="#">www.irezon.com</a></p>
      <p class="fl_right">Free from  <a target="_blank" href="http://www.irezon.com/" title="Free Website Templates">Irezon</a></p>
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>