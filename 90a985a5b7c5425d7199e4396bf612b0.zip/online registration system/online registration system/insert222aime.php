<?php
require('connection.php');
$name=$_POST['name'];
$email=$_POST['email'];
$message=$_POST['message'];
$exec = $conn->query("INSERT INTO customer(name,email,message)VALUES('$name','$email','$message')");
if($exec){
	echo "INSERTED SUCCESS";
}
else{
	echo "<script>alert('not INSERTED SUCCESS')</sccript>";
}
?>