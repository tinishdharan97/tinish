<?php
session_start();
require('connection.php');
?>
<?php
$error ="";
?>
<?php
if(isset($_POST['signin'])){
$password = $_POST['password'];
$email = $_POST['email'];
$sql="SELECT  `email`, `password` FROM `user` WHERE `email`='$email' && `password`='$password' ";
$link=mysqli_query($con,$sql);
if(empty($email) && empty($password)){
  ?>
  <script>
  alert("Empty Email Or Password");
  </script>
  <?php
}
else{
   if(mysqli_num_rows($link)){
while($row=mysqli_fetch_assoc($link));
$_SESSION["email"]=$email;
$_SESSION["password"]=$password;
header('location:adminhome.php');
}
else{
  ?>
  <script>
  alert("Incrorect Email Or Password");
  </script>
  <?php
}
}
}
?>
<html >
<head>
<title>School Name</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" type="text/css" media="screen" href="bootstrap.css" />
<script src="jquery-2.2.4.js"></script>
<style>
    #body{
margin-top: 5%;
width: 50%;
border-radius: o;
margin: auto;
}
.form-group{
width: 70%;
}
.form-control{
border-radius: 0;
}
form{
text-align: -webkit-center;
}
</style>
</head>
<body id="top">
<div class="wrapper col1">
  <div id="head">
    <h1><a href="index.html">School Name</a></h1>
    <p>School Moto</p>
    <div id="topnav">
      <ul>
        <li><a class="active" href="index.php">Home</a></li>
        <li><a href="index.php">Log out</a></li>
     </ul>
    </div>
  </div>
<div class="wrapper col4">
<div class="clear">
<h1 align="center"class="text-primary">Login</h1>
<div class="list-group-item" style="border-radius: 0;border: 0;" id="header">
</div>
<div class="container" id="all-body">
<fieldset class="list-group-item" id="body">
<form action="login.php" method="post">
<div class="form-group" >
<h2 class="text-primary">User signin</h2>
</div>
<div class="form-group" style="text-align:start;" >
<legend></legend>
</div>
<div class="form-group">
<h5 class="text-primary"></h5>
</div>
<div class="form-group" style="text-align:start;" >
<label for="email" style="font-size: 17px;">Email</label>
<input type="email" class="form-control" name="email" id="email">
</div>
<div class="form-group" style="text-align:start">
<label for="pass" style="font-size: 17px;">Password</label>
<input type="password" class="form-control" name="password" id="password">
</div>
<div class="form-group">
<input type="submit" class="btn btn-primary" value="SignIn" name="signin" id="signup" >
</div>

</form>
</fieldset><br>
</div>
<div class="footer">
</div>
</div>
<div class="wrapper col5">
  <div id="footer">
    <div id="contactform">
     </div>
     <div id="compdetails">
     <div id="officialdetails">
     </div>
     <div id="contactdetails">
     </div>
    <div class="clear"></div>
    </div>
    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2019 - All Rights Reserved - <a href="#">Irezon</a></p>
      <p class="fl_right">free from  <a target="_blank" href="http://irezon.com/" title="Free Website Templates">irezon</a></p>
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>