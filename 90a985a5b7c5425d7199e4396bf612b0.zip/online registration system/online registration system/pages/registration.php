<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Corporation | Style Demo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="../layout/styles/layout.css" type="text/css" />
</head>
<body id="top">
<div class="wrapper col1">
  <div id="head">
    <h1><a href="../index.html">Corporation</a></h1>
    <p>Free Website Template</p>
    <div id="topnav">
      <ul>
          <li><a class="active" href="first project corporation/index.html">Home</a></li>
        <li><a href="pages/registration.php">Registration</a></li>
         <li><a href="pages/registration.php">Dashboard</a></li>
       
      </ul>
    </div>
  
  </div>
</div>
<div class="wrapper col2">
  <div id="breadcrumb">
    <ul>
      <li class="first">You Are Here</li>
      <li>&#187;</li>
      <li><a href="index.htmk">Home</a></li>
      <li>&#187;</li>
      <li><a href="https://www.irezon.com/">find</a></li>
      <li>&#187;</li>
      <li><a href="https://www.irezon.com/">more</a></li>
      <li>&#187;</li>
      <li class="current"><a href="https://www.irezon.com/">Irezon</a></li>
    </ul>


<div class="wrapper col2">
 
<h1>registration menus and others</h1>

    <div class="clear"></div>
  </div></div>
  </div>
<div class="wrapper col5">
  <div id="footer">
    <div id="contactform">
      <h2>Why Not Contact Us Today !</h2>
      <form action="#" method="post">
        <fieldset>
          <legend>Contact Form</legend>
          <label for="fullname">Name:
            <input id="fullname" name="fullname" type="text" value="" />
          </label>
          <label for="emailaddress" class="margin">Email:
            <input id="emailaddress" name="emailaddress" type="text" value="" />
          </label>
          <label for="phone">Telephone:
            <input id="phone" name="phone" type="text" value="" />
          </label>
          <label for="subject" class="margin">Subject:
            <input id="subject" name="subject" type="text" value="" />
          </label>
          <label for="message">Message:<br />
            <textarea id="message" name="message" cols="40" rows="4"></textarea>
          </label>
          <p>
            <input id="submitform" name="submitform" type="submit" value="Submit" />
            &nbsp;
            <input id="resetform" name="resetform" type="reset" value="Reset" />
          </p>
        </fieldset>
      </form>
    </div>
    <!-- End Contact Form -->
    <div id="compdetails">
      <div id="officialdetails">
        <h2>SchoolInformation !</h2>
        <ul>
          <li>SchoolName Ltd</li>
          <li>Registered in England &amp; Wales</li>
          <li>SchoolNo. xxxxxxx</li>
          <li class="last">VAT No. xxxxxxxxx</li>
        </ul>
        <h2>Stay in The Know !</h2>
        <p><a href="#">Get Our E-Newsletter</a> | <a href="#">Grab The RSS Feed</a></p>
      </div>
      <div id="contactdetails">
        <h2>Our Contact Details !</h2>
        <ul>
          <li>SchoolName</li>
          <li>Street Name &amp; Number</li>
          <li>Town</li>
          <li>Postcode/Zip</li>
          <li>Tel: xxxx xxx xxx </li>
          <li>Email: info@domain.com</li>
          <li class="last">LinkedIn: <a href="#">SchoolProfile</a></li>
        </ul>
      </div>
      <div class="clear"></div>
    </div>
    
    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2019 - All Rights Reserved - <a href="#">Irezon</a></p>
      <p class="fl_right">free from  <a target="_blank" href="http://irezon.com/" title="Free Website Templates">irezon</a></p>
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>