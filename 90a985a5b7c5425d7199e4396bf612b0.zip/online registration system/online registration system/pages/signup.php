<?php
include ('connection.php');
if (isset($_POST['signupform'])) {
	$name = $_POST['email'];
	$email = $_POST['password'];
	$sql = "INSERT INTO `user`(`email`, `password`) VALUES ('$email','$password')";
	$link = mysqli_query($con,$sql);
	if ($link) {
		?>
		<script>
		alert("signup completed ");
        </script>
		<?php
        header('location:admin.php');
	}	
		?>
		<script>
		alert("there is problem in your signup please try again");
		</script>
		<?php

}
?>