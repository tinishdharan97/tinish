<?php
$server="localhost";
$user="root";
$pass="";
$db="school";
$con=mysqli_connect($server,$user,$pass,$db) or die("could not connct");

if(isset($_POST['regist'])){
$email=$_POST['email'];
$firstname=$_POST['first_name'];
$lastname=$_POST['last_name'];
$age=$_POST['age'];
$gender=$_POST['gender'];
$option=$_POST['option'];
$class=$_POST['class'];
$telephone=$_POST['telephone'];
$sql = "INSERT INTO `insert`(`email`, `first_name`, `last_name`, `age`, `gender`, `option`, `class`, `telephone`)
 VALUES ('$email','$firstname','$lastname','$age','$gender','$option','$class','$telephone') ";
$gnz = mysqli_query($con,$sql);
if ($gnz) {
	?>
	<script>
	alert("You have been registed");
	</script>
	<?php
}
else{
	?>
	<script>
	alert("You didn't registed");
	</script>
	<?php
}
}
?>
