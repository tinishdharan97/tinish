<?php
require('connection.php');
require('deletecomment.php');
?>
<html >
<head>
<title>School Name</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="bootstrap.css">
</head>
<body id="top">
<div class="wrapper col1">
  <div id="head">
    <h1><a href="index.html">School Name</a></h1>
    <p>School Moto</p>
    <div id="topnav">
      <ul>
        <li><a  href="index.php">Home</a></li>
        <li><a  href="admin.php">Manage</a></li>
        <li><a class="active" href="">Comment</a></li>
        <li><a href="index.php">Log out</a></li>
        
       
      </ul>
    </div>
  
  </div>
</div>
<div class="text-center">
  
<h2 class="text-primary">Admin now you can modify the comments</h2>
</div>
<div>
 
 <div class="table-responsive">
 <?php
include 'connection.php';
$query= "SELECT * FROM `message`";
$data = mysqli_query($con,$query);
?>
<table class="table table-bordered">
<tr>
<th>Id</th>
<th>Name</th>
<th>Email</th>
<th>Comment</th>
<th>Delete</th>

</tr>
<?php
if (mysqli_num_rows($data)) {
  while ($row=mysqli_fetch_assoc($data)) {
  ?>
    <form action="comment.php?id=<?php echo $row['id']; ?> " method="POST" >
    <tr>
    <td><?php echo $row["id"]; ?></td>
    <td><?php echo $row["fullname"]; ?></td>
    <td><?php echo $row["emailadress"]; ?></td>
    <td> <?php echo $row["messag"]; ?></td>
    <td> <button class="btn btn-danger" name="delete"> Delete </button> </td>
    </tr>
    </form>
    <?php
}
}
echo '</table>';
?>

 </div>
 
    <div class="clear"></div>
  </div>
</div>

      
    </div>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col5">
  <div id="footer">
    <div id="contactform">
      <h2>ADMIN</h2>
      <form action="#" method="post">
        
      </form>
    </div>
    <div id="compdetails">
      <div id="officialdetails">
        <h2>ADMIN</h2>
       
       
      </div>
      <div id="contactdetails">
      
      </div>
      <div class="clear"></div>
    </div>
  
    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2019 - All Rights Reserved - <a href="#">www.irezon.com</a></p>
      <p class="fl_right">Free from  <a target="_blank" href="http://www.irezon.com/" title="Free Website Templates">Irezon</a></p>
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>