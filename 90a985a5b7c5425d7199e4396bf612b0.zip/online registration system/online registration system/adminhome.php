<?php
require('connection.php');
require('delete.php');
require('update.php');
?>
<html >
<head>
<title>School Name</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="layout/styles/layout.css" type="text/css" />
<link rel="stylesheet" href="bootstrap.css">
<style>

</style>
</head>
<body id="top">
<div class="wrapper col1">
  <div id="head">
    <h1><a href="index.html">School Name</a></h1>
    <p>School Moto</p>
    <div id="topnav">
      <ul>
        <li><a class="active" href="">Home</a></li>
         <li><a  href="admin.php">Manage</a></li>
        <li><a  href="comment.php">Comment</a></li>
        <li><a href="index.php">Log out</a></li>
        
       
      </ul>
    </div>
  
  </div>
</div>
<div class="text-center">
  
<h1 class="text-primary" style="padding:2px 2px;">Welcome Admin</h1><br><br>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6">
        <p class="text-primary" style="font-size:16px;">
            Welcome admin now you can modify this website <br>
            from your knowledge about web design and web <br>
            management so you can click to the button above<br>
            help you to change some content by modifying the <br>registrated
             students on this on line system 
        </p><br>
        <div class="text-center" style="width:60%;">
                <a href="admin.php"><button class="btn btn-primary" 
                    style="border-radius:0px; box-shadow:0px 1px 3px 5px rgba(23, 104, 196, 0.712); width:100px;height:50px;">Manage</button></a>
        </div>
        </div>
        
        <div class="col-md-6">
                <p class="text-primary" style="font-size:16px;">
                    Welcome admin now you can modify this website <br>
                    from your knowledge about web design and web <br>
                    management so you can click to the button above<br>
                    help you to change some content by modifying the<br> 
                    comments for our user 
                </p> <br>
                <div class="text-center" style="width:60%;">
                <a href="comment.php"><button class="btn btn-primary" 
                     style="border-radius:0px; box-shadow:0px 1px 3px 5px rgba(23, 104, 196, 0.712); width:100px;height:50px;">Comment</button></a>
                 </div>
                </div>
    </div>
    <br><br><br>
</div>

    <div class="clear"></div>
  </div>
</div>

      
    </div>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col5">
  <div id="footer">
    <div id="contactform">
      <h2>ADMIN</h2>
      <form action="#" method="post">
        
      </form>
    </div>
    <div id="compdetails">
      <div id="officialdetails">
        <h2>ADMIN</h2>
       
       
      </div>
      <div id="contactdetails">
      
      </div>
      <div class="clear"></div>
    </div>
  
    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2019 - All Rights Reserved - <a href="#">www.irezon.com</a></p>
      <p class="fl_right">Free from  <a target="_blank" href="http://www.irezon.com/" title="Free Website Templates">Irezon</a></p>
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>