COPYRIGHT � Irezon.COM 
ALL RIGHTS RESERVED 
 
 
This work is under Creative Commons Attribution http://Irezon.com description: 
This system is for online students registration it consist of student registration panel and adminstrator panel. 
 
 
Language used: 
1.Html 2.PHP 3.javascript 
For more information visit: http://www.Irezon.com/ 
 
Installation Instructions: 
1.After download zipped folder open that folder 
2.Copy in the server 
3.import database.sql file into your DBMS [folder:database/school.sql] 
4.Simple edit index.php and add your own content 

5.Run the index.php file 

N.B:Admin
    -email: admin@gmail.com  
    -password: admin 
For more information visite www.irezon.com

 
